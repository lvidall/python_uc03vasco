from django.contrib import admin

from .models import Perfil, Comentario

admin.site.register(Perfil)

admin.site.register(Comentario)